﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace StringReader1
{
    class Program
    {
        static void Main(string[] args)
        {
            //#1
            //string s = @"Hello all This is a multi-line text string";
            //StringReader rdr = new StringReader(s);

            //// Проверить, нет ли еще символов
            //while (rdr.Peek() != -1)
            //{
            //    string line = rdr.ReadLine();
            //    Console.WriteLine(line);
            //}

            
            //#2
            //StringWriter writer = new StringWriter();
            //writer.WriteLine("Hello all");
            //writer.WriteLine("This is a multi-line");
            //writer.WriteLine("text string");
            //Console.WriteLine(writer.ToString());





        }
    }
}
